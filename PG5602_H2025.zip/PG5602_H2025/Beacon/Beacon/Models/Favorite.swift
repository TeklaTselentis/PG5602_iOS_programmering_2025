// SwiftData modell for favoritter.

import Foundation
import SwiftData

@Model
final class Favorite {
    // MARK: Felt lagret i SwiftData
    @Attribute(.unique) var id: String
    var placeId: String
    var createdAt: Date

    var name: String
    var address: String?
    var lat: Double
    var lon: Double
    var categoryRaw: String

    // MARK: Init
    init(placeId: String,
         createdAt: Date = .now,
         name: String,
         address: String?,
         lat: Double,
         lon: Double,
         categoryRaw: String) {
        self.id = UUID().uuidString
        self.placeId = placeId
        self.createdAt = createdAt
        self.name = name
        self.address = address
        self.lat = lat
        self.lon = lon
        self.categoryRaw = categoryRaw
    }
}

