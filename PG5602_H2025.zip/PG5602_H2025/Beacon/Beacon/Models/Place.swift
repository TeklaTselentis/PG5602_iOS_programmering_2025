// Representerer ett sted fra APIet (Geoapify)

import Foundation
import CoreLocation

struct Place: Identifiable, Codable, Equatable {
    let id: String
    let name: String
    let address: String?
    let lat: Double
    let lon: Double
    let category: PlaceCategory

    var coordinate: CLLocationCoordinate2D {
        .init(latitude: lat, longitude: lon)
    }
}
