// SwiftData mmodell for brukervurderig.

import Foundation
import SwiftData

@Model
final class Rating {
    // MARK: Felt lagret i SwiftData.
    @Attribute(.unique) var id: String
    var placeId: String
    var value: Int
    var date: Date
    
    // MARK: Init
    init(placeId: String, value: Int, date: Date = .now) {
        self.id = UUID().uuidString
        self.placeId = placeId
        self.value = value
        self.date = date
    }
}
