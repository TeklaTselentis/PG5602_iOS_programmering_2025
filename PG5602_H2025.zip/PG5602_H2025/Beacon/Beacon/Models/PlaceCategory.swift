// Kategorier for steder i appen.

import Foundation

enum PlaceCategory: String, CaseIterable, Codable, Identifiable {
    case restaurant, cafe, hotel
    var id: String { rawValue }

    var title: String {
        switch self {
        case .restaurant: return "Restaurant"
        case .cafe:       return "Kafè"
        case .hotel:      return "Hotell"
        }
    }

    var emoji: String {
        switch self {
        case .restaurant: return "🍽"
        case .cafe:       return "☕"
        case .hotel:      return "🏨"
        }
    }

    var geoapifyTag: String {
        switch self {
        case .restaurant: return "catering.restaurant"
        case .cafe:       return "catering.cafe"
        case .hotel:      return "accommodation.hotel"
        }
    }
}
