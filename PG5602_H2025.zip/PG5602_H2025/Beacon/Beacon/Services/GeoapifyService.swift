// Snakker med Geoapify Places API, og mapper svaret til en liste av Place

import Foundation
import CoreLocation

struct GeoapifyService {
    
    // MARK: Egendefinert API-feil
    struct APIError: Error, LocalizedError { let message: String; var errorDescription: String? { message } }

    // MARK: Hente API nøkkel fra Secrets.plist
    private func apiKey() throws -> String {
        guard let url = Bundle.main.url(forResource: "Secrets", withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let dict = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
              let key = dict["GEOAPIFY_API_KEY"] as? String, !key.isEmpty else {
            throw APIError(message: "Mangler API-nøkkel. Legg inn GEOAPIFY_API_KEY i Secrets.plist")
        }
        return key
    }

    // MARK: Hente steder fra Geoapify
    func fetchPlaces(
        center: CLLocationCoordinate2D,
        radiusKm: Double,
        category: PlaceCategory,
        text: String? = nil) async throws -> [Place] {
        let key = try apiKey()
        let radiusMeters = Int(radiusKm * 1000)
        var comps = URLComponents(string: "https://api.geoapify.com/v2/places")!
        
        
        var items: [URLQueryItem] = [
            .init(name: "categories", value: category.geoapifyTag),
            .init(name: "filter", value: "circle:\(center.longitude),\(center.latitude),\(radiusMeters)"),
            .init(name: "bias", value: "proximity:\(center.longitude),\(center.latitude)"),
            .init(name: "limit", value: "15"),
            .init(name: "apiKey", value: key)
        ]
        
        if let t = text, !t.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            items.append(.init(name: "name", value: t))
        }
        comps.queryItems = items
        guard let url = comps.url else { throw APIError(message: "Ugyldig URL") }

        print("GeoapifyService: GET \(url.absoluteString)")

        let (data, resp) = try await URLSession.shared.data(from: url)

        if let http = resp as? HTTPURLResponse {
            print("GeoapifyService: status \(http.statusCode)")
            guard http.statusCode == 200 else {
                throw APIError(message: "Serverfeil \(http.statusCode)")
            }
        }

        // MARK: Dekoding og mapping til Place
        do {
            let result = try JSONDecoder().decode(GeoapifyPlacesResponse.self, from: data)
            print("GeoapifyService: dekodet \(result.features.count) features")

            
            let mapped: [Place] = result.features.compactMap { f in
                guard let coords = f.geometry.coordinates, coords.count >= 2 else { return nil }
                let lon = coords[0]
                let lat = coords[1]

                let props = f.properties
                let id = props.placeIdString ?? props.osmIdString ?? props.datasource?.raw?["place_id"] ?? UUID().uuidString

                return Place(
                    id: id,
                    name: props.name ?? props.formatted ?? "Uten navn",
                    address: props.formatted,
                    lat: lat,
                    lon: lon,
                    category: category
                )
            }
            return mapped
        } catch {
            
            if let text = String(data: data, encoding: .utf8) {
                print("GeoapifyService: decode error: \(error). Raw JSON:\n\(text)")
            } else {
                print("GeoapifyService: decode error: \(error). (kunne ikke konvertere data til tekst)")
            }
            throw APIError(message: "Uventet datastruktur fra serveren")
        }
    }
}

// MARK: GeoJSON responsmodeller (kun brukt internt)

private struct GeoapifyPlacesResponse: Decodable {
    let features: [Feature]

    struct Feature: Decodable {
        let geometry: Geometry
        let properties: Properties
    }

    struct Geometry: Decodable {
        let type: String?
        let coordinates: [Double]?
    }

    struct Properties: Decodable {
        let name: String?
        let formatted: String?

        private let place_id_int: Int?
        private let place_id_string: String?
        private let osm_id_int: Int?
        private let osm_id_string: String?

        let datasource: Datasource?

        enum CodingKeys: String, CodingKey {
            case name
            case formatted
            case place_id
            case osm_id
            case datasource
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            name = try container.decodeIfPresent(String.self, forKey: .name)
            formatted = try container.decodeIfPresent(String.self, forKey: .formatted)

            if let intVal = try? container.decodeIfPresent(Int.self, forKey: .place_id) {
                place_id_int = intVal
                place_id_string = nil
            } else if let strVal = try? container.decodeIfPresent(String.self, forKey: .place_id) {
                place_id_int = nil
                place_id_string = strVal
            } else {
                place_id_int = nil
                place_id_string = nil
            }


            if let intVal = try? container.decodeIfPresent(Int.self, forKey: .osm_id) {
                osm_id_int = intVal
                osm_id_string = nil
            } else if let strVal = try? container.decodeIfPresent(String.self, forKey: .osm_id) {
                osm_id_int = nil
                osm_id_string = strVal
            } else {
                osm_id_int = nil
                osm_id_string = nil
            }

            datasource = try container.decodeIfPresent(Datasource.self, forKey: .datasource)
        }

        var placeIdString: String? {
            if let s = place_id_string { return s }
            if let i = place_id_int { return String(i) }
            return nil
        }

        var osmIdString: String? {
            if let s = osm_id_string { return s }
            if let i = osm_id_int { return String(i) }
            return nil
        }

        struct Datasource: Decodable {
            let raw: [String: String]?

            enum CodingKeys: String, CodingKey {
                case raw
            }

            init(from decoder: Decoder) throws {
                let container = try decoder.container(keyedBy: CodingKeys.self)

                if let dict = try? container.decodeIfPresent([String: String].self, forKey: .raw) {
                    self.raw = dict
                } else {
                    self.raw = nil
                }
            }
        }
    }
}
