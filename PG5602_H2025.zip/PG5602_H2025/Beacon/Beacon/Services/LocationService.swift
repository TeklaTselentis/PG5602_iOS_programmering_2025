// Enkel tjeneste rundt CCLocationManager.

import Foundation
import CoreLocation
import Combine

final class LocationService: NSObject, ObservableObject, CLLocationManagerDelegate {
    
    // MARK: Publiserte verdier til UI
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published var currentLocation: CLLocationCoordinate2D?

    // MARK: Intern CCLocationManager
    private let manager = CLLocationManager()

    // MARK: Init
    override init() {
        super.init()
        manager.delegate = self
    }

    // MARK: Offentlig metodekall
    func request() {
        manager.requestWhenInUseAuthorization()
    }

    func locate() {
        manager.requestLocation()
    }

    // MARK: CCLocationManagerDelegate
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
        if authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways {
            manager.requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        currentLocation = locations.last?.coordinate
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {}
}
