// Viser alle lagrede favoritter. Støtter filtrering, søk, sortering og åpning av detaljvisning. Her er toggle for "Vis kun favoritter" fjernet.

import SwiftUI
import SwiftData
import CoreLocation

struct FavoritesView: View {
    
    // MARK: SwiftData
    @Query(sort: [SortDescriptor(\Favorite.createdAt, order: .reverse)])
    private var favorites: [Favorite]
    @Environment(\.modelContext) private var context

    // MARK: Filter og UI state
    @StateObject private var filtersVM = FiltersViewModel()
    @State private var showFilters = false
    @State private var favCategory: FavoritesCategory = .all
    @State private var selectedPlace: Place?

    // MARK: Bakgrunn
    private func darkGlassBackground(cornerRadius: CGFloat = 22, overlayOpacity: Double = 0.62) -> some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .fill(.thinMaterial)
            .overlay(
                Color("DeepBlue").opacity(overlayOpacity)
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
    }

    // MARK: Filtrerte favoritter
    private var filteredFavorites: [Favorite] {
        
        // 1. Filtrer på kategori
        let byCategory: [Favorite] = {
            // 1. Filtrer på
            switch favCategory {
            case .all: return favorites
            case .restaurant: return favorites.filter { $0.categoryRaw == PlaceCategory.restaurant.rawValue }
            case .cafe:       return favorites.filter { $0.categoryRaw == PlaceCategory.cafe.rawValue }
            case .hotel:      return favorites.filter { $0.categoryRaw == PlaceCategory.hotel.rawValue }
            }
        }()

        // 2. Filtrer på søketekst
        let trimmed = filtersVM.query.trimmingCharacters(in: .whitespacesAndNewlines)
        let byQuery: [Favorite]
        if trimmed.isEmpty {
            byQuery = byCategory
        } else {
            let q = trimmed.lowercased()
            byQuery = byCategory.filter { fav in
                fav.name.lowercased().contains(q) ||
                (fav.address?.lowercased().contains(q) ?? false)
            }
        }

        // 3. Filtrer etter sortering
        var sorted = byQuery
        switch filtersVM.sortOrder {
        case .distance:
            
            let center = AppConstants.defaultCenter
            sorted.sort { a, b in
                let da = CLLocation(latitude: a.lat, longitude: a.lon)
                    .distance(from: CLLocation(latitude: center.latitude, longitude: center.longitude))
                let db = CLLocation(latitude: b.lat, longitude: b.lon)
                    .distance(from: CLLocation(latitude: center.latitude, longitude: center.longitude))
                return da < db
            }
        case .alphabetic:
            sorted.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .rating:
            
            sorted.sort { avgRating(for: $0) > avgRating(for: $1) }
        }
        return sorted
    }

    // MARK: UI
    var body: some View {
        NavigationStack {
            ZStack {
                Color("DeepBlue").ignoresSafeArea()

                VStack(spacing: 12) {
                    
                    // MARK: Kategori velger
                    HStack(spacing: 12) {
                        FavoritesCategorySegmentedView(selection: $favCategory)
                            .frame(maxWidth: .infinity)
                            .frame(height: 40)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 6)
                            .background(
                                
                                RoundedRectangle(cornerRadius: 22, style: .continuous)
                                    .fill(.thinMaterial)
                                    .overlay(
                                        Color("DeepBlue").opacity(0.82)
                                            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                    )
                            )
                            .shadow(color: .black.opacity(0.10), radius: 10, x: 0, y: 4)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)

                    // MARK: Tilbakemelding og filter-knapp
                    HStack {
                        FoundCountBadge(count: filteredFavorites.count)
                        Spacer()
                        Button { showFilters = true } label: {
                            Image(systemName: "slider.horizontal.3")
                                .foregroundStyle(.white)
                                .frame(width: 40, height: 40)
                                .background(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .fill(.thinMaterial)
                                        .overlay(
                                            Color("DeepBlue").opacity(0.82)
                                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                                .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                        )
                                )
                                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 16)

                    // MARK: Tomtilstand eller liste med favoritter
                    if filteredFavorites.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "heart")
                                .font(.system(size: 44, weight: .semibold))
                                .foregroundStyle(.white.opacity(0.9))

                            Text("Ingen favoritter enda")
                                .font(.headline)
                                .foregroundStyle(.white.opacity(0.95))

                            Text("Legg til et sted som favoritt fra kartet eller listevisningen.")
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.7))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)
                        }
                        .padding(.top, 20)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    } else {
                        ScrollView {
                            VStack(spacing: 16) {
                                ForEach(filteredFavorites) { fav in
                                    let place = Place(
                                        id: fav.placeId,
                                        name: fav.name,
                                        address: fav.address,
                                        lat: fav.lat,
                                        lon: fav.lon,
                                        category: PlaceCategory(rawValue: fav.categoryRaw) ?? .restaurant
                                    )

                                    Button {
                                        selectedPlace = place
                                    } label: {
                                        PlaceRowView(place: place,
                                                     currentCenter: AppConstants.defaultCenter,
                                                     darkGlassOverlayOpacity: 0.82)
                                            .background(darkGlassBackground(overlayOpacity: 0.82))
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 22, style: .continuous)
                                                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                            )
                                            .shadow(color: .black.opacity(0.14), radius: 12, x: 0, y: 5)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.bottom, 12)
                            .padding(.top, 6)
                        }
                        .background(Color.clear)
                    }
                }
            }
            // MARK: Filter sheet
            .sheet(isPresented: $showFilters) {
                ZStack {
                    Color(.clear).ignoresSafeArea(edges: .horizontal)
                    FiltersSheetView(vm: filtersVM,
                                     onClear: { filtersVM.clearAll() },
                                     showOnlyFavoritesToggle: false)
                }
                .presentationBackground(.clear)
                .presentationDetents([.fraction(0.4)])
            }
            // MARK: Detaljvisning
            .sheet(item: $selectedPlace) { place in
                ZStack {
                    Color("DeepBlue").ignoresSafeArea(edges: .horizontal)
                    PlaceDetailView(place: place)
                }
                .presentationBackground(.clear)
                .presentationDetents([.fraction(0.76)])
                .presentationDragIndicator(.visible)
            }
            // MARK: onAppear for refresh
            .onAppear {
                filtersVM.onQueryChanged = { _ in /* trigger view update via @StateObject */ }
                filtersVM.onSortChanged = { _ in /* trigger view update via @StateObject */ }
            }
        }
    }

    // MARK: Gjennomsnittlig rating for favoritt
    private func avgRating(for fav: Favorite) -> Double {
        let targetId = fav.placeId
        let desc = FetchDescriptor<Rating>(predicate: #Predicate<Rating> { $0.placeId == targetId })
        guard let all = try? context.fetch(desc), !all.isEmpty else {
            return 0.0
        }
        let sum = all.map { $0.value }.reduce(0, +)
        return Double(sum) / Double(all.count)
    }
}

// MARK: Lokale komponenter
private enum FavoritesCategory: CaseIterable, Identifiable {
    case all, restaurant, cafe, hotel
    var id: String {
        switch self {
        case .all: return "all"
        case .restaurant: return PlaceCategory.restaurant.rawValue
        case .cafe: return PlaceCategory.cafe.rawValue
        case .hotel: return PlaceCategory.hotel.rawValue
        }
    }
    var title: String {
        switch self {
        case .all: return "Alle"
        case .restaurant: return "Restaurant"
        case .cafe: return "Kafé"
        case .hotel: return "Hotell"
        }
    }
}

// MARK: segmentert kategorivinsing
private struct FavoritesCategorySegmentedView: View {
    @Binding var selection: FavoritesCategory

    var body: some View {
        HStack(spacing: 8) {
            ForEach(FavoritesCategory.allCases) { cat in
                let isSelected = (selection == cat)
                Button {
                    selection = cat
                    Haptics.tap()
                } label: {
                    Text(cat.title)
                        .font(.callout.weight(.semibold))
                        .fixedSize(horizontal: true, vertical: false)
                        .padding(.horizontal, 14)
                        .frame(height: 40)
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(isSelected ? Color("BeaconOrange") : Color.clear)
                        )
                        .foregroundStyle(.white)
                        .shadow(color: isSelected ? Color.black.opacity(0.08) : .clear, radius: 6, x: 0, y: 2)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(2)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.clear)
        )
    }
}

// MARK: Tilbakemelding med antall resultater
private struct FoundCountBadge: View {
    let count: Int
    var body: some View {
        Label("\(count) steder", systemImage: "mappin")
            .font(.callout)
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .frame(height: 34)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay(
                        Color("DeepBlue").opacity(0.82)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
            )
            .shadow(color: .black.opacity(0.10), radius: 8, x: 0, y: 3)
    }
}
