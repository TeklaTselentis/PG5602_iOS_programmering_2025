// Henter steder fra Geoapify basert på posisjon, radius, kategori og søk.

import SwiftUI
import MapKit
import CoreLocation
import Combine
import SwiftData

@MainActor
final class ExploreViewModel: ObservableObject {
    
    // MARK: Publiserte verdier til UI
    @Published var category: PlaceCategory = .restaurant
    @Published var isMapMode = true
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var places: [Place] = []

    // MARK: Avhengigheter
    private let geo: GeoapifyService

    // MARK: Init
    init(geo: GeoapifyService) {
        self.geo = geo
    }

    convenience init() {
        self.init(geo: GeoapifyService())
    }

    // MARK: Hente steder fra Geoapify
    func fetch(center: CLLocationCoordinate2D,
               radiusKm: Double,
               query: String? = nil,
               sort: SortOrder = .distance,
               context: ModelContext) async {
        isLoading = true;
        errorMessage = nil
        defer { isLoading = false }
        
        do {
            var loaded = try await geo.fetchPlaces(
                center: center,
                radiusKm: radiusKm,
                category: category,
                text: query)
            
            // Sorterer resultatende basert på valgt sorteringsmetode(avstand, alfabetisk eller rating)
            switch sort {
            case .distance:
                loaded.sort { a, b in
                    let da = CLLocation(latitude: a.lat, longitude: a.lon).distance(from: CLLocation(latitude: center.latitude, longitude: center.longitude))
                    let db = CLLocation(latitude: b.lat, longitude: b.lon).distance(from: CLLocation(latitude: center.latitude, longitude: center.longitude))
                    return da < db
                }
            case .alphabetic:
                loaded.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            case .rating:
                if !loaded.isEmpty {
                    let ids = Set(loaded.map { $0.id })
                    let desc = FetchDescriptor<Rating>(predicate: #Predicate { ids.contains($0.placeId) }, sortBy: [])
                    let ratings = (try? context.fetch(desc)) ?? []
                    if !ratings.isEmpty {
                        var sums: [String: (sum: Int, count: Int)] = [:]
                        for r in ratings {
                            let entry = sums[r.placeId] ?? (0, 0)
                            sums[r.placeId] = (entry.sum + r.value, entry.count + 1)
                        }
                        let averages: [String: Double] = sums.reduce(into: [:]) { dict, pair in
                            let (pid, agg) = pair
                            dict[pid] = Double(agg.sum) / Double(agg.count)
                        }
                        loaded.sort { (averages[$0.id] ?? 0) > (averages[$1.id] ?? 0) }
                    }
                }
            }
            
            // MARK: Logging til konsoll
            if let first = loaded.first {
                print("ExploreViewModel: loaded = \(loaded.count). First: \(first.name) @ \(first.lat),\(first.lon)")
            } else {
                print("ExploreViewModel: loaded = 0")
            }
            places = loaded
        } catch {
            errorMessage = "Noe gikk galt: " + (error.localizedDescription)
        }
    }
}
