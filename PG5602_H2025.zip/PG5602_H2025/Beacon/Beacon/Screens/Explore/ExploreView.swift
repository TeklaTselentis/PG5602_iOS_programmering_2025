// Hovedskjerm for "Utforsk" med kart og listevisning.
// Henter steder fra APIet basert på posisjon, filter, søk, og viser steder på kart og liste.

import SwiftUI
import MapKit
import SwiftData

struct ExploreView: View {
    
    // MARK: ViewModels
    @ObservedObject var exploreVM: ExploreViewModel
    @ObservedObject var filtersVM: FiltersViewModel

    // MARK: Lagring av kart senter (AppStorage)
    @AppStorage(AppStorageKeys.centerLatitude)
    private var centerLat: Double = AppConstants.defaultCenter.latitude
    @AppStorage(AppStorageKeys.centerLongitude)
    private var centerLon: Double = AppConstants.defaultCenter.longitude

    // MARK: Kart og visningsstae
    @State private var region: MKCoordinateRegion = .around(AppConstants.defaultCenter)
    @State private var showFilters = false
    @State private var selectedPlace: Place?

    // MARK: Lokasjonstjeneste
    @StateObject private var locationService = LocationService()
    @State private var locationDeniedMessage: String?
    @State private var shouldUseNextLocation = false

    // MARK: SwiftData kontekst
    @Environment(\.modelContext) private var context
    private var mapFlat: AnyShapeStyle { AnyShapeStyle(Color.white) }

    // MARK: Layout for knapper øverst
    @State private var topControlsHeight: CGFloat = 0
    
    // MARK: Location picker og søkstate
    @State private var showLocationPicker = false
    @State private var searchText: String = ""
    @State private var searchSuggestions: [MKLocalSearchCompletion] = []
    @State private var isPickingOnMap = false
    @State private var isSearching = false
    private let searchCompleter = MKLocalSearchCompleter()
    @State private var pickRegion: MKCoordinateRegion = .around(AppConstants.defaultCenter)

    // MARK: Oppstartsflagg
    @State private var didInitializeRegion = false
    @State private var hasFetchedAtLeastOnce = false

    // MARK: UI
    var body: some View {
        ZStack(alignment: .top) {

            content
                .padding(.top, topInsetForContent)

            if exploreVM.isLoading {
                let isMap = exploreVM.isMapMode
                VStack(spacing: 10) {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(isMap ? Color("DeepBlue") : .white)
                        .scaleEffect(1.2)

                    Text("Søker…")
                        .font(.callout.weight(.semibold))
                        .foregroundStyle(isMap ? Color("DeepBlue") : .white.opacity(0.95))
                }
                .padding(.vertical, 16)
                .padding(.horizontal, 20)
                .background(
                    Group {
                        if isMap {
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(Color.white)
                        } else {
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(.thinMaterial)
                                .overlay(
                                    Color("DeepBlue").opacity(0.82)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                )
                        }
                    }
                )
                .shadow(color: .black.opacity(isMap ? 0.12 : 0.18), radius: isMap ? 10 : 16, x: 0, y: isMap ? 4 : 8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .transition(.opacity)
            }

            // MARK: Feilmelding fra ExploreViewModel
            if let err = exploreVM.errorMessage {
                VStack {
                    Spacer()
                    Text(err)
                        .font(.footnote)
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(Color.red.opacity(0.9), in: RoundedRectangle(cornerRadius: 12))
                        .padding(.bottom, 16)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .animation(.easeInOut, value: exploreVM.errorMessage)
            }

            // MARK: Meldinger om lokasjonstilgang
            if let denied = locationDeniedMessage {
                VStack {
                    Spacer()
                    Text(denied)
                        .font(.footnote)
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(Color.orange.opacity(0.95), in: RoundedRectangle(cornerRadius: 12))
                        .padding(.bottom, 16)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .animation(.easeInOut, value: locationDeniedMessage)
            }

            // MARK: Kategori og "Hent" knapp
            VStack(spacing: 0) {
                TopControlsCard(
                    isMapMode: exploreVM.isMapMode,
                    category: exploreVM.category,
                    placesCount: placesForDisplay().count,
                    categoryView: {
                        CategorySegmentedView(
                            selection: $exploreVM.category,
                            textColor: exploreVM.isMapMode ? .primary : .white
                        )
                    },
                    fetchAction: {

                        if isPickingOnMap {
                            let coord = pickRegion.center
                            moveRegion(to: coord)
                            isPickingOnMap = false
                        }
                        hasFetchedAtLeastOnce = true
                        fetchAction()
                    }
                )
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .background(
                    GeometryReader { proxy in
                        Color.clear
                            .onAppear { topControlsHeight = proxy.size.height + 12 }
                            .onChange(of: proxy.size.height) { _, new in
                                topControlsHeight = new + 12
                            }
                    }
                )

                Spacer(minLength: 0)
            }
            
            // MARK: Knapp for å bytte mellom kart/liste og filterknapp
            TopRightButtons(
                isMapMode: exploreVM.isMapMode,
                listGlassStyle: AnyShapeStyle(.ultraThinMaterial),
                onToggle: {
                    exploreVM.isMapMode.toggle()
                    Haptics.tap()
                },
                onShowFilters: { showFilters = true }
            )

            // MARK: Zoom knapper
            if exploreVM.isMapMode {
                GeometryReader { geo in
                    let midY = geo.size.height / 2
                    VStack(spacing: 10) {
                        Button { zoom(by: 0.6) } label: { Text("+").font(.headline) }
                            .buttonStyle(SmallRoundButtonStyle(backgroundStyle: mapFlat))
                        Button { zoom(by: 1.4) } label: { Text("-").font(.headline) }
                            .buttonStyle(SmallRoundButtonStyle(backgroundStyle: mapFlat))
                    }
                    .position(x: geo.size.width - 36, y: midY)
                }
            }

            // MARK: "Velg posisjon" og GPS knapp
            if exploreVM.isMapMode {
                VStack {
                    Spacer()
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Velg posisjon")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.primary)
                                .padding(.horizontal, 6)

                            Button {
                                openLocationPicker()
                                Haptics.tap()
                            } label: {

                                Label(isPickingOnMap ? pickRegion.center.shortString : region.center.shortString,
                                      systemImage: "magnifyingglass")
                                    .font(.callout)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .fill(Color.white)
                                    )
                                    .foregroundStyle(Color("DeepBlue"))
                            }
                            .buttonStyle(.plain)
                            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
                        }

                        Spacer()

                        GPSButton { onGPS() }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)
                }
            }
        }
        .background(exploreVM.isMapMode ? Color.clear : Color("DeepBlue"))
        // MARK: Filter sheet
        .sheet(isPresented: $showFilters) {
            FiltersSheetView(vm: filtersVM,
                             onClear: { filtersVM.clearAll() })
                .presentationDetents([.fraction(0.40)])
        }
        // MARK: Velg posisjon sheet
        .sheet(isPresented: $showLocationPicker) {
            locationPickerSheet
                .presentationDetents([.fraction(0.40)])
        }
        // MARK: Detaljvisning sheet
        .sheet(item: $selectedPlace) { place in
            ZStack {
                Color("DeepBlue").ignoresSafeArea(edges: .horizontal)
                PlaceDetailView(place: place)
            }
            .presentationBackground(.clear)
            .presentationDetents([.fraction(0.76)])
            .presentationDragIndicator(.visible)
        }
        // MARK: Oppstart / wiring av callbacks
        .task {

            if !didInitializeRegion {
                let storedCenter = CLLocationCoordinate2D(latitude: centerLat, longitude: centerLon)
                let isStoredValid = CLLocationCoordinate2DIsValid(storedCenter)
                let initialCenter = isStoredValid ? storedCenter : AppConstants.defaultCenter
                region = .around(initialCenter)
                didInitializeRegion = true
            }

            filtersVM.onQueryChanged = { _ in
                guard hasFetchedAtLeastOnce else { return }
                fetchAction()
            }
            filtersVM.onSortChanged = { _ in
                guard hasFetchedAtLeastOnce else { return }
                fetchAction()
            }

            setupSearchCompleter()

        }
        // MARK: Lagring av endring av kartsenter
        .onChange(of: region.center.shortString) { _, _ in
            centerLat = region.center.latitude
            centerLon = region.center.longitude
        }
        // MARK: Lagring av endring av pickRegion når bruker velger på kartet
        .onChange(of: pickRegion.center.shortString) { _, _ in

            if isPickingOnMap {
                centerLat = pickRegion.center.latitude
                centerLon = pickRegion.center.longitude
            }
        }
        // MARK: Refetching når kategori endres
        .onChange(of: exploreVM.category) { _, _ in
            guard hasFetchedAtLeastOnce else { return }
            fetchAction()
        }
        // MARK: Reagerer på ny lokasjon fra LocationService
        .onReceive(locationService.$currentLocation) { loc in
            guard shouldUseNextLocation, let c = loc else { return }
            region = .around(c)
            centerLat = c.latitude
            centerLon = c.longitude
            shouldUseNextLocation = false
            hasFetchedAtLeastOnce = true
            fetchAction()
        }
        // MARK: Håndterer endring i lokasjonstillatelse
        .onChange(of: locationService.authorizationStatus) { _, newStatus in
            if newStatus == .denied || newStatus == .restricted {
                locationDeniedMessage = "Posisjonstilgang er avslått. Gi tilgang i Innstillinger for å bruke «nær meg»."
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) { locationDeniedMessage = nil }
            }
        }
    }

    // MARK: Layout: topp padding for innhold
    private var topInsetForContent: CGFloat {
        exploreVM.isMapMode ? 0 : topControlsHeight
    }

    // MARK: Rating snitt
    private func averageRatings(for places: [Place]) -> [String: Double] {
        let ids = Set(places.map { $0.id })
        guard !ids.isEmpty else { return [:] }
        let desc = FetchDescriptor<Rating>(predicate: #Predicate { ids.contains($0.placeId) }, sortBy: [])
        let ratings = (try? context.fetch(desc)) ?? []
        guard !ratings.isEmpty else { return [:] }

        var sums: [String: (sum: Int, count: Int)] = [:]
        for r in ratings {
            let entry = sums[r.placeId] ?? (0, 0)
            sums[r.placeId] = (entry.sum + r.value, entry.count + 1)
        }

        var avgs: [String: Double] = [:]
        for (pid, agg) in sums {
            avgs[pid] = Double(agg.sum) / Double(agg.count)
        }
        return avgs
    }

    // MARK: Hovedinnhold (karte eller liste)
    @ViewBuilder
    private var content: some View {
        
        let all = placesForDisplay()
        
        let displayBase = hasFetchedAtLeastOnce ? all : []

 
        let display: [Place] = {
            guard !displayBase.isEmpty,
                  !exploreVM.isMapMode,
                  filtersVM.sortOrder == .rating
            else {
                return displayBase
            }

            let avgs = averageRatings(for: displayBase)
            return displayBase.sorted {
                (avgs[$0.id] ?? 0) > (avgs[$1.id] ?? 0)
            }
        }()

        if exploreVM.isMapMode {
            if isPickingOnMap {
                MapContainerView(region: $pickRegion, places: display) { place in
                    selectedPlace = place
                }
            } else {
                MapContainerView(region: $region, places: display) { place in
                    selectedPlace = place
                }
            }
        } else {
            let trimmedQuery = filtersVM.query.trimmingCharacters(in: .whitespacesAndNewlines)
            let hasActiveQuery = !trimmedQuery.isEmpty
            
            let emptyReason: EmptyReason = !hasFetchedAtLeastOnce
                ? .notFetchedYet
                : ((display.isEmpty && hasActiveQuery) ? .filteredOut : .noResultsNearby)

            PlacesListView(
                places: display,
                currentCenter: region.center,
                onSelect: { place in selectedPlace = place },
                emptyReason: emptyReason
            )
            .refreshable {
                hasFetchedAtLeastOnce = true
                fetchAction()
            }
        }
    }


    // MARK: Henter steder fra ExploreViewModel
    private func fetchAction() {
        Task {
            await exploreVM.fetch(center: region.center,
                                  radiusKm: filtersVM.radiusKm,
                                  query: filtersVM.query.isEmpty ? nil : filtersVM.query,
                                  sort: filtersVM.sortOrder,
                                  context: context)
        }
    }

    // MARK: GPS knapp håndtering
    private func onGPS() {
        shouldUseNextLocation = true
        locationService.request()
        locationService.locate()
    }

    // MARK: Zoom på kart
    private func zoom(by factor: Double) {
        var span = region.span
        span.latitudeDelta = max(0.0005, span.latitudeDelta * factor)
        span.longitudeDelta = max(0.0005, span.longitudeDelta * factor)
        region.span = span
    }

    // MARK: Favoritthjelpere
    private func favoriteIDs() -> Set<String> {
        let descriptor = FetchDescriptor<Favorite>(sortBy: [])
        let favorites = (try? context.fetch(descriptor)) ?? []
        return Set(favorites.map { $0.placeId })
    }

    private func placesForDisplay() -> [Place] {
        guard filtersVM.onlyFavorites else { return exploreVM.places }
        let ids = favoriteIDs()
        return exploreVM.places.filter { ids.contains($0.id) }
    }


    // MARK: Posisjons velger hjelpere

    private func openLocationPicker() {
        searchText = ""
        searchSuggestions = []
        showLocationPicker = true
        pickRegion = region
        isPickingOnMap = true
    }

    private func setupSearchCompleter() {
        searchCompleter.resultTypes = [.address, .pointOfInterest]
        searchCompleter.region = MKCoordinateRegion(
            center: region.center,
            span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5)
        )
        searchCompleter.pointOfInterestFilter = .includingAll
    }

    private func updateSuggestions(for query: String) {
        searchCompleter.queryFragment = query
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 150_000_000)
            self.searchSuggestions = self.searchCompleter.results
        }
    }

    private func searchAndMove(to completion: MKLocalSearchCompletion) {
        isSearching = true
        let request = MKLocalSearch.Request(completion: completion)
        let search = MKLocalSearch(request: request)
        Task {
            let response = try? await search.start()
            await MainActor.run {
                self.isSearching = false
                if let item = response?.mapItems.first, let coord = item.placemark.location?.coordinate {
                    moveRegion(to: coord)
                    showLocationPicker = false
                    isPickingOnMap = false
                    hasFetchedAtLeastOnce = true
                    fetchAction()
                }
            }
        }
    }

    private func moveRegion(to coord: CLLocationCoordinate2D) {
        region = .around(coord)
        centerLat = coord.latitude
        centerLon = coord.longitude
    }


    // MARK: Velg posisjon sheet
    private var locationPickerSheet: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Søk etter adresse eller sted")
                    .font(.headline)
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Oslo, Bergen, Storgata 1…", text: $searchText)
                        .textInputAutocapitalization(.words)
                        .disableAutocorrection(true)
                        .onChange(of: searchText) { _, new in
                            updateSuggestions(for: new)
                        }
                }
                .padding(.horizontal, 12)
                .frame(height: 44)
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(Color(.systemGray6))
                )

                if isSearching {
                    ProgressView().padding(.vertical, 4)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 8)
        

            Divider()

            ScrollView {
                        LazyVStack(alignment: .leading, spacing: 0) {
                            ForEach(searchSuggestions, id: \.self) { item in
                                Button {
                                    searchAndMove(to: item)
                                    Haptics.tap()
                                } label: {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(item.title)
                                            .font(.body.weight(.semibold))
                                        if !item.subtitle.isEmpty {
                                            Text(item.subtitle)
                                                .font(.subheadline)
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    .padding(.vertical, 6)
                                    .padding(.horizontal, 16)
                                }

                                Divider()
                                    .padding(.leading, 16)
                            }
                        }
                    }
                    .background(Color.clear)
                }
        .background(Color("DeepBlue").opacity(0.0))
    }
}


// MARK: Kategori og Hent
private struct TopControlsCard<CatView: View>: View {
    let isMapMode: Bool
    let category: PlaceCategory
    let placesCount: Int
    let categoryView: () -> CatView
    let fetchAction: () -> Void

    private func cardBackground(isMap: Bool) -> some View {
        Group {
            if isMap {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(Color.white)
            } else {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay(
                        Color("DeepBlue").opacity(0.82)
                            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
            }
        }
    }

    private func badgeBackground(isMap: Bool) -> some View {
        Group {
            if isMap {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white)
            } else {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay(
                        Color("DeepBlue").opacity(0.82)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
            }
        }
    }

    private func noun(for category: PlaceCategory, count: Int) -> String {
        switch category {
        case .restaurant: return count == 1 ? "restaurant" : "restauranter"
        case .cafe: return count == 1 ? "kafé" : "kaféer"
        case .hotel: return count == 1 ? "hotell" : "hoteller"
        }
    }

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 12) {
                categoryView()
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 6)
                    .background(cardBackground(isMap: isMapMode))
                    .shadow(color: .black.opacity(isMapMode ? 0.12 : 0.10), radius: 10, x: 0, y: 4)
                    .foregroundColor(isMapMode ? .primary : .white)

                Button(action: fetchAction) {
                    Label("Hent", systemImage: "arrow.down.circle")
                        .font(.callout.weight(.semibold))
                        .padding(.horizontal, 16)
                        .frame(height: 40)
                        .background(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .fill(Color("BeaconOrange"))
                        )
                        .foregroundStyle(.white)
                }
                .buttonStyle(.plain)
            }

            if placesCount > 0 {
                HStack {
                    Label("\(placesCount) \(noun(for: category, count: placesCount)) funnet", systemImage: "mappin")
                        .font(.callout)
                        .padding(.horizontal, 12)
                        .frame(height: 34)
                        .background(badgeBackground(isMap: isMapMode))
                        .foregroundColor(isMapMode ? .primary : .white)
                        .shadow(color: .black.opacity(isMapMode ? 0.12 : 0.10), radius: 8, x: 0, y: 3)

                    Spacer()
                }
                .padding(.top, 6)
            }
        }
    }
}

// MARK: Kart/Liste og Filter
private struct TopRightButtons: View {
    let isMapMode: Bool
    let listGlassStyle: AnyShapeStyle
    let onToggle: () -> Void
    let onShowFilters: () -> Void

    private func listBackground() -> some View {
        RoundedRectangle(cornerRadius: 12, style: .continuous)
            .fill(.thinMaterial)
            .overlay(
                Color("DeepBlue").opacity(0.82)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
    }

    var body: some View {
        HStack(spacing: 10) {
            Button(action: onToggle) {
                Image(systemName: isMapMode ? "list.bullet" : "map")
                    .foregroundColor(isMapMode ? .primary : .white)
                    .frame(width: 40, height: 40)
                    .background(
                        Group {
                            if isMapMode {
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.white)
                            } else {
                                listBackground()
                            }
                        }
                    )
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
            }
            .buttonStyle(.plain)

            Button(action: onShowFilters) {
                Image(systemName: "slider.horizontal.3")
                    .foregroundColor(isMapMode ? .primary : .white)
                    .frame(width: 40, height: 40)
                    .background(
                        Group {
                            if isMapMode {
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.white)
                            } else {
                                listBackground()
                            }
                        }
                    )
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
            }
            .buttonStyle(.plain)
        }
        .padding(.trailing, 16)
        .padding(.top, 72)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
    }
}
