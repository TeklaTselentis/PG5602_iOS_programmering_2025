// Viser en scrolleliste med steder.

import SwiftUI
import CoreLocation
import SwiftData

struct PlacesListView: View {
    
    // MARK: Inndata
    var places: [Place]
    var currentCenter: CLLocationCoordinate2D
    var onSelect: (Place) -> Void
    var emptyReason: EmptyReason = .noResultsNearby

    // MARK: Bakgrunn for hver rad
    private func darkGlassBackground(cornerRadius: CGFloat = 22, overlayOpacity: Double = 0.62) -> some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .fill(.thinMaterial)
            .overlay(
                Color("DeepBlue").opacity(overlayOpacity)
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            )
    }

    // MARK: UI
    var body: some View {
        if places.isEmpty {
            EmptyStateView(reason: emptyReason)
                .padding()
        } else {
            ScrollView {
                VStack(spacing: 16) {
                    ForEach(places) { place in
                        Button {
                            onSelect(place)
                        } label: {
                            PlaceRowView(place: place,
                                         currentCenter: currentCenter,
                                         darkGlassOverlayOpacity: 0.82)
                                .background(darkGlassBackground(overlayOpacity: 0.82))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                )
                                .shadow(color: .black.opacity(0.14), radius: 12, x: 0, y: 5)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 12)
                .padding(.top, 6)
            }
            .background(Color.clear)
        }
    }
}
