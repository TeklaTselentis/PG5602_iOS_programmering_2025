// Viser en segmentert kategori velger (Resturant, Kafé, Hotell), og oppdaterer valgt kategori via en @Binding som andre views kan bruke.

import SwiftUI

struct CategorySegmentedView: View {
    
    // MARK: Inndata
    
    // Nåværende valgt kategori.
    @Binding var selection: PlaceCategory
    
    // Tekstfarge for ikke-valgte knapper.
    var textColor: Color = .primary
    
    
    // MARK: Tekst for kategorier
    private func displayTitle(for cat: PlaceCategory) -> String {
        switch cat {
        case .restaurant: return "Resturant"
        case .cafe:       return "Kafé"
        case .hotel:      return "Hotell"
        }
    }

    // MARK: UI
    var body: some View {
        HStack(spacing: 8) {
            ForEach(PlaceCategory.allCases) { cat in
                let isSelected = (selection == cat)
                Button {
                    selection = cat
                    Haptics.tap()
                } label: {
                    Text(displayTitle(for: cat))
                        .font(.callout.weight(.semibold))
                        .fixedSize(horizontal: true, vertical: false)
                        .padding(.horizontal, 14)
                        .frame(height: 40)
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(isSelected ? Color("BeaconOrange") : Color.clear)
                        )
                        .foregroundStyle(isSelected ? .white : textColor)
                        .shadow(color: isSelected ? Color.black.opacity(0.08) : .clear, radius: 6, x: 0, y: 2)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(2)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.clear)
        )
    }
}
