// Viser et ark med filtreringsinnstillinger for søk (tekst, radius, sortering og favoritter).
// Oppdaterer FiltersViewModel direkte via bindinger og kall på funksjoner.

import SwiftUI

struct FiltersSheetView: View {
    
    // MARK: Inndata og avhengigheter
    
    // ViewModel som eier filtertilstand. Endringer her påvirker søk og visning i andre views.
    @ObservedObject var vm: FiltersViewModel
    
    // Kjøres når bruker trykker "Nullstill filter. Overordnet view bestemmer hva som faktisk skjer.
    var onClear: () -> Void

    // Styrer om "Vis kun lagrede favoritter" skal vises.
    var showOnlyFavoritesToggle: Bool = true

    // MARK: UI
    var body: some View {
        
        VStack(spacing: 16) {
            Text("Filter")
                .font(.title3)
                .bold()
                .padding(.top, 16)

            TextField("Søk etter steder…", text: $vm.query)
                .textFieldStyle(.roundedBorder)
                .onChange(of: vm.query) { _, _ in vm.debounceQuery() }

            VStack(alignment: .leading) {
                Text("Søkeradius: \(Int(vm.radiusKm)) km")
                Slider(value: $vm.radiusKm, in: AppConstants.minRadiusKm...AppConstants.maxRadiusKm, step: 1)
            }

            Picker("Sortering", selection: $vm.sortOrder) {
                Text("Avstand (nærmest først)").tag(SortOrder.distance)
                Text("Rating (høyest først)").tag(SortOrder.rating)
                Text("Alfabetisk (A–Å)").tag(SortOrder.alphabetic)
            }
            .pickerStyle(.menu)
            .onChange(of: vm.sortOrder) { _, _ in vm.changedSort() }

            if showOnlyFavoritesToggle {
                Toggle("Vis kun lagrede favoritter", isOn: $vm.onlyFavorites)
            }

            Button("Nullstill filter", role: .destructive, action: onClear)
                .buttonStyle(.bordered)

            Spacer(minLength: 0)
        }
        .padding()
    }
}
