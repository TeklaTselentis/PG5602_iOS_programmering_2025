// Holder og lagrer filterverdier og gir enkle callbacks når søk eller sortering skjer.

import SwiftUI
import Combine

// MARK: Sorteringsvalg for søkeresultat
enum SortOrder: String, CaseIterable, Identifiable {
    case distance, rating, alphabetic
    var id: String { rawValue }
}


// MARK: Filter viewmodel
@MainActor
final class FiltersViewModel: ObservableObject {
    
    // MARK: Publiserte filterverdier
    // Søkeradius som lagres i AppStorage
    @AppStorage(AppStorageKeys.searchRadiusKm) var radiusKm: Double = 5
    
    // Tekst søk på sted/navn
    @Published var query: String = ""
    
    // Valgt sorteringsmetode
    @Published var sortOrder: SortOrder = .distance
    
    // Om kun favoritter skal vise
    @Published var onlyFavorites = false

    // MARK: Debounce og callbacks
    // Brukes for å utsette søk litt når bruker skriver
    private let debouncer = Debouncer()
    // Kalles etter debounce når query endres
    var onQueryChanged: ((String) -> Void)?
    // Kalles når sorteringsvalg endres
    var onSortChanged: ((SortOrder) -> Void)?

    // MARK: Håndtering av søk
    // Debouncer søketeksten sånn at det ikke søker for hvert tastetrykk
    // Kalles fra TextField.onChange i FilterSheetView
    func debounceQuery() {
        Task {
            await debouncer.schedule(ms: AppConstants.debounceMs) { [weak self] in
                guard let self else { return }
                Task { @MainActor in self.onQueryChanged?(self.query) }
            }
        }
    }

    // MARK: Håndtering av sortering
    // Varsler lyttere om at sorteringsvalget er endret.
    // Kalles fra Picker.onChange i FilterSheetView
    func changedSort() {
        onSortChanged?(sortOrder)
    }

    // MARK: Nullstilling av filtre
    // Tilbakestiller alle filterverdiene til standard.
    func clearAll() {
        query = ""
        radiusKm = 5
        sortOrder = .distance
        onlyFavorites = false
        onQueryChanged?(query)
        onSortChanged?(sortOrder)
    }
}
