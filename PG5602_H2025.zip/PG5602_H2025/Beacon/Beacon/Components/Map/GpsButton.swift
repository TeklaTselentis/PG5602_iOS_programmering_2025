// GPS knapp som brukes til å velge "min posisjon" på kartet

import SwiftUI

struct GPSButton: View {
    // MARK: Inndata
    // Kjøres når brukeren trykker på knappen
    var action: () -> Void

    // MARK: Konfigurasjon
    private let size: CGFloat = 44
    private let iconSize: CGFloat = 16

    // MARK: UI
    var body: some View {
        Button(action: action) {
            Image(systemName: "location.fill")
                .font(.system(size: iconSize, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(Color("BeaconOrange"))
                .clipShape(Circle())
                .shadow(color: .black.opacity(0.18), radius: 14, x: 0, y: 7)
        }
        .buttonStyle(.plain)
    }
}
