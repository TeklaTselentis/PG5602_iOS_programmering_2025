// Viser MapKit kart med annotasjoner for steder.
// Legger på snittrating ved å hente rating fra SwiftData

import SwiftUI
import MapKit
import SwiftData

struct MapContainerView: View {
    
    // MARK: Inndata
    // Kartregion (senter + zoom). Oppdateres når brukeren panorerer/zoomer.
    @Binding var region: MKCoordinateRegion
    
    // Listen av steder som skal vises som pins på kartet.
    var places: [Place]
    // Kalles når bruker trykker på en annotasjon.
    var onTapPlace: (Place) -> Void

    // MARK: SwiftData
    @Environment(\.modelContext) private var context

    // MARK: Lokal tilstand
    @State private var ratingsVersion: Int = 0

    // MARK: Snittrating per sted
    // Regner ut gjennomsnittlig rating per placeID for alle stedr på kartet.
    private func averageRatings(for places: [Place]) -> [String: Double] {
        let ids = Set(places.map { $0.id })
        guard !ids.isEmpty else { return [:] }
        let desc = FetchDescriptor<Rating>(
            predicate: #Predicate { ids.contains($0.placeId) },
            sortBy: []
        )
        let ratings = (try? context.fetch(desc)) ?? []
        guard !ratings.isEmpty else { return [:] }

        var sums: [String: (sum: Int, count: Int)] = [:]
        for r in ratings {
            let entry = sums[r.placeId] ?? (0, 0)
            sums[r.placeId] = (entry.sum + r.value, entry.count + 1)
        }

        var avgs: [String: Double] = [:]
        for (pid, agg) in sums {
            avgs[pid] = Double(agg.sum) / Double(agg.count)
        }
        return avgs
    }

    // MARK: Kart
    var body: some View {
        
        let _ = ratingsVersion
        let avgs = averageRatings(for: places)

        Map(
            coordinateRegion: $region,
            interactionModes: .all,
            showsUserLocation: false,
            annotationItems: places,
            annotationContent: { place in
                let avg = avgs[place.id]
                return MapAnnotation(coordinate: place.coordinate) {
                    Button {
                        onTapPlace(place)
                    } label: {
                        PlaceAnnotationView(place: place, averageRating: avg)
                    }
                    .buttonStyle(.plain)
                }
            }
        )
        .mapStyle(.standard)
        .ignoresSafeArea()
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("ratingDidChange"))) { _ in
            ratingsVersion &+= 1
        }
    }
}
