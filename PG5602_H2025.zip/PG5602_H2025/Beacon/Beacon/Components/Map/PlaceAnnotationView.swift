// Tegner ut en annotasjon(pin) for et sted, vise også avrundet rating.
import SwiftUI

struct PlaceAnnotationView: View {
    
    // MARK: Inndata
    let place: Place
    let averageRating: Double?

    // MARK: Avrundet rating
    private var roundedStars: Int? {
        guard let avg = averageRating, avg > 0 else { return nil }
        
        return max(1, min(5, Int((avg).rounded())))
    }

    // MARK: UI
    var body: some View {
        ZStack(alignment: .topTrailing) {
            
            Image(systemName: "mappin.circle.fill")
                .imageScale(.large)
                .foregroundStyle(Color("BeaconOrange"))

            if let stars = roundedStars {
                
                HStack(spacing: 2) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(Color("BeaconOrange"))
                    Text("\(stars)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(Color("BeaconOrange"))
                }
                .padding(.horizontal, 4).padding(.vertical, 2)
                .background(
                    Capsule(style: .circular)
                        .fill(Color.white)
                        .overlay(
                            Capsule(style: .circular)
                                .stroke(Color.black.opacity(0.15), lineWidth: 0.8)
                        )
                )
                .offset(x: 8, y: -8)
            }
        }
    }
}
