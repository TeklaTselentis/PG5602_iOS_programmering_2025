// Viser en rad for et sted i listevisning (navn, kategori, adresse, avstand, rating).
// Håndterer også lagring/sletting av favoritt og henter gjennomsnittlig rating fra SwiftData.

import SwiftUI
import CoreLocation
import SwiftData

struct PlaceRowView: View {
    
    // MARK: Inndata
    // Resultatet som skal vises i raden
    let place: Place
    // Brukes til å beregne avstand til stedet.
    let currentCenter: CLLocationCoordinate2D
    // Glasseffekt for raden
    let darkGlassOverlayOpacity: Double

    // MARK: SwiftData og lokal tilstand
    // Swiftdata kontekst for å lese/lagre favoritter og rating
    @Environment(\.modelContext) private var context
    // Om stedet er lagret som favoritt
    @State private var isFavorite = false
    // Gjennomsnittlig rating for stedet (1-5), hvis det finnes.
    @State private var avgRating: Double?

    // MARK: Farger brukt i raden
    private let primaryText = Color.white.opacity(0.96)
    private let secondaryText = Color.white.opacity(0.72)

    // MARK: Hoved UI
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                CategoryBadge(category: place.category)

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(place.name)
                            .font(.headline.weight(.semibold))
                            .foregroundStyle(primaryText)
                        // Viser fylt stjerne hvis vi har snittrating
                        if let avg = avgRating {
                            SingleStarPill(fill: CGFloat(min(max(avg / 5.0, 0), 1)),
                            overlayOpacity: darkGlassOverlayOpacity)
                        }
                    }

                    Text(place.category.title)
                        .font(.subheadline)
                        .foregroundStyle(secondaryText)
                }

                Spacer()

                // Favoritt knapp
                FavoriteGlassButton(
                    isOn: isFavorite, overlayOpacity: darkGlassOverlayOpacity) {
                    toggleFavorite()
                }
            }

            // Viser adresse hvis vi har det.
            if let addr = place.address {
                HStack(spacing: 8) {
                    Image(systemName: "mappin.and.ellipse")
                        .foregroundStyle(secondaryText)
                    Text(addr)
                        .foregroundStyle(secondaryText)
                        .font(.subheadline)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                }
            }

            Divider().overlay(Color.white.opacity(0.08))

            HStack {
                HStack(spacing: 8) {
                    Circle().fill(Color.orange).frame(width: 6, height: 6)
                    Text(distanceString())
                        .font(.subheadline)
                        .foregroundStyle(secondaryText)
                }

                Spacer()

                HStack(spacing: 4) {
                    Text("Se detaljer")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color("BeaconOrange"))
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color("BeaconOrange"))
                }
            }
        }
        .padding(EdgeInsets(top: 14, leading: 16, bottom: 14, trailing: 16))
        // Henting av favorittstaus og snittrating
        .onAppear {
            isFavorite = checkFavorite()
            avgRating = computeAverageRating()
        }
        // Oppdatering av snittrating når det skjer endringer på stedet.
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("ratingDidChange"))) { notif in
            guard let id = notif.object as? String, id == place.id else { return }
            avgRating = computeAverageRating()
        }
    }

    // MARK: Avstand (beregning og tekst)
    // Lager en tekst med avstand i km fra currentCenter til place
    private func distanceString() -> String {
        let user = CLLocation(latitude: currentCenter.latitude, longitude: currentCenter.longitude)
        let dest = CLLocation(latitude: place.lat, longitude: place.lon)
        let meters = user.distance(from: dest)
        let km = meters / 1000.0
        return String(format: "%.1f km unna", km)
    }

    // MARK: Favoritt håndtering
    // Mulighet til å legge til som favoritt gjennom listevisningen.
    private func toggleFavorite() {
        if let existing = fetchFavorite() {
            context.delete(existing)
        } else {
            context.insert(Favorite(
                placeId: place.id,
                name: place.name,
                address: place.address,
                lat: place.lat,
                lon: place.lon,
                categoryRaw: place.category.rawValue
            ))
        }
        try? context.save()
        isFavorite = checkFavorite()
    }

    // Henter favoritt objektet
    private func fetchFavorite() -> Favorite? {
        let desc = FetchDescriptor<Favorite>(predicate: #Predicate { $0.placeId == place.id }, sortBy: [])
        return (try? context.fetch(desc))?.first
    }

    // Sjekker om stedet er lagret som favoritt
    private func checkFavorite() -> Bool { fetchFavorite() != nil }

    
    // MARK: Rating (bergening av snitt)
    // Henter alle ratinger for stedet og regner ut gjennomsnitt
    private func computeAverageRating() -> Double? {
        let desc = FetchDescriptor<Rating>(predicate: #Predicate { $0.placeId == place.id }, sortBy: [])
        if let all = try? context.fetch(desc), !all.isEmpty {
            let avg = Double(all.map { $0.value }.reduce(0, +)) / Double(all.count)
            return avg
        }
        return nil
    }
}

// MARK: Delkomponenter brukt i raden
// Badge som viser kategori emoji
private struct CategoryBadge: View {
    let category: PlaceCategory
    var body: some View {
        Text(category.emoji)
            .font(.system(size: 16, weight: .bold))
            .frame(width: 36, height: 36)
            .background(Color("BeaconOrange").opacity(0.20))
            .foregroundStyle(Color("BeaconOrange"))
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

// Stjerne som kan fylles delvis, brukes for rating
private struct SingleStarPill: View {
    let fill: CGFloat
    let overlayOpacity: Double

    var body: some View {
        HStack(spacing: 6) {
            PercentFilledStar(fill: fill)
                .frame(width: 16, height: 16)
        }
        .padding(.horizontal, 8).padding(.vertical, 4)
        .background(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(.thinMaterial)
                .overlay(Color("DeepBlue").opacity(overlayOpacity))
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }
}

// Stjerne som fylles fra venstre til høyre basert på fill (0-1)
private struct PercentFilledStar: View {
    let fill: CGFloat 

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ZStack {
                Image(systemName: "star")
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(Color.white.opacity(0.35))

                Image(systemName: "star.fill")
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(Color("BeaconOrange"))
                    .mask(
                        Rectangle()
                            .frame(width: w * max(0, min(1, fill)), alignment: .leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    )
            }
        }
        .aspectRatio(1, contentMode: .fit)
    }
}

// Favoritt knapp
private struct FavoriteGlassButton: View {
    var isOn: Bool
    var overlayOpacity: Double
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: isOn ? "heart.fill" : "heart")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(Color("BeaconOrange"))
                .frame(width: 36, height: 36)
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(.thinMaterial)
                        .overlay(Color("DeepBlue").opacity(overlayOpacity))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
