// Animasjon til detaljvisning iht kravene i oppgave 3.

import SwiftUI

// MARK: Kategori animasjon til header i detaljvisning
struct CategoryHeaderAnimation: View {
    
    let category: PlaceCategory
    @Binding var animate: Bool

    var body: some View {
        switch category {
        case .restaurant:
            Text("🍽").font(.system(size: 56))
                .rotationEffect(.degrees(animate ? 360 : 0))
                .animation(.easeInOut(duration: 1), value: animate)

        case .cafe:
            ZStack {
                Text("☕").font(.system(size: 56))
                HStack(spacing: 12) {
                    steam(offset: -10, delay: 0.0)
                    steam(offset: 0, delay: 0.2)
                    steam(offset: 10, delay: 0.4)
                }
                .offset(y: -28)
            }

        case .hotel:
            Text("🏨").font(.system(size: 56))
                .scaleEffect(animate ? 1.0 : 0.5)
                .animation(.spring(response: 0.5, dampingFraction: 0.5), value: animate)
        }
    }

    private func steam(offset: CGFloat, delay: Double) -> some View {
        Text("💨").opacity(animate ? 0.0 : 1.0)
            .offset(y: animate ? -40 : 0)
            .animation(.easeOut(duration: 1).delay(delay).repeatForever(autoreverses: false), value: animate)
            .offset(x: offset)
    }
}
