// Gjenbrukbar rad med ikon, tittel og verdi.

import SwiftUI

struct InfoRow: View {
    // MARK: Inndata
    let systemImage: String
    let title: String
    let value: String
    var valueColor: Color = .white
    var darkOverlayOpacity: Double = 0.0
    var iconDarkOverlayOpacity: Double = 0.0

    // MARK: UI
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                IconBackground(cornerRadius: 12, iconDarkOverlayOpacity: iconDarkOverlayOpacity)

                Image(systemName: systemImage)
                    .foregroundStyle(Color("BeaconOrange"))
                    .font(.system(size: 16, weight: .semibold))
            }
            .frame(width: 36, height: 36)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.7))
                Text(value)
                    .font(.body)
                    .foregroundStyle(valueColor)
            }

            Spacer()
        }
        .padding(14)
        .background(
            CardBackground(cornerRadius: 18, darkOverlayOpacity: darkOverlayOpacity)
        )
    }
}

// MARK: Ikonbakgrunn
private struct IconBackground: View {
    let cornerRadius: CGFloat
    let iconDarkOverlayOpacity: Double

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)

        return shape
            .fill(.thinMaterial)
            .overlay(iconOverlay(shape: shape))
            .overlay(
                shape.stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
    }

    @ViewBuilder
    private func iconOverlay(shape: RoundedRectangle) -> some View {
        if iconDarkOverlayOpacity > 0 {
            Color("DeepBlue")
                .opacity(iconDarkOverlayOpacity)
                .clipShape(shape)
        }
    }
}

// MARK: Kort bakgrunn
private struct CardBackground: View {
    let cornerRadius: CGFloat
    let darkOverlayOpacity: Double

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)

        return shape
            .fill(.thinMaterial)
            .overlay(darkOverlay(shape: shape))
            .overlay(
                shape.stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
    }

    @ViewBuilder
    private func darkOverlay(shape: RoundedRectangle) -> some View {
        if darkOverlayOpacity > 0 {
            Color("DeepBlue")
                .opacity(darkOverlayOpacity)
                .clipShape(shape)
        }
    }
}
