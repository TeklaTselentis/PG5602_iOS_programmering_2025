// Viser detaljsheet for et sted (navn, adresse, aktegori, koordinter, rating, kartknapp etc.)
// Lar brukeren rate stedet og markere som favoritt.

import SwiftUI
import MapKit
import SwiftData

struct PlaceDetailView: View {
    
    // MARK: Inndata
    let place: Place
    @State private var animate = false

    @Environment(\.modelContext) private var context

    @State private var ratingValue: Int = 3
    @State private var isFavorite: Bool = false
    @State private var avgRating: Double? = nil

    // MARK: Farger og layout konstanter
    private let primaryText = Color.white.opacity(0.96)
    private let secondaryText = Color.white.opacity(0.72)
    private let hPad: CGFloat = 12
    private let badgeSize: CGFloat = 72

    // MARK: Hoved UI
    var body: some View {
        ZStack {
            Color("DeepBlue").ignoresSafeArea()

            ScrollView {
                VStack(spacing: 12) {

                    HStack {
                        Spacer()
                        Circle()
                            .fill(Color("BeaconOrange"))
                            .frame(width: badgeSize, height: badgeSize)
                            .overlay(
                                CategoryHeaderAnimation(category: place.category, animate: $animate)
                                    .scaleEffect(0.82)
                            )
                            .shadow(color: .black.opacity(0.20), radius: 10, x: 0, y: 6)
                        Spacer()
                    }
                    .padding(.top, 8)

                    VStack(alignment: .center, spacing: 6) {
                        HStack(spacing: 8) {
                            Text(place.name)
                                .font(.title3.weight(.bold))
                                .foregroundStyle(primaryText)
                                .lineLimit(2)
                                .multilineTextAlignment(.center)

                            if let avg = avgRating {
                                HStack(spacing: 4) {
                                    SingleFilledStarView(fill: CGFloat(min(max(avg / 5.0, 0), 1)))
                                        .frame(width: 16, height: 16)
                                    Text(String(format: "%.1f", avg))
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(secondaryText)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)

                        if let addr = place.address {
                            Text(addr)
                                .font(.footnote)
                                .foregroundStyle(secondaryText)
                                .multilineTextAlignment(.center)
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                        }

                        // Koordinater med BeaconOrange pin til venstre
                        HStack(spacing: 6) {
                            Image(systemName: "mappin.and.ellipse")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(Color("BeaconOrange"))
                            Text(place.coordinate.shortString)
                                .font(.caption)
                                .foregroundStyle(secondaryText)
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .padding(.horizontal, hPad)

                    ratingCard
                        .padding(.horizontal, hPad)

                    VStack(spacing: 10) {
                        InfoRow(
                            systemImage: "square.grid.2x2",
                            title: "Kategori",
                            value: place.category.title,
                            valueColor: primaryText,
                            darkOverlayOpacity: 0.82,
                            iconDarkOverlayOpacity: 0.64
                        )

                        InfoRow(
                            systemImage: "clock",
                            title: "Åpningstider",
                            value: "Mo–Su 15:00–23:00",
                            valueColor: primaryText,
                            darkOverlayOpacity: 0.82,
                            iconDarkOverlayOpacity: 0.64
                        )
                    }
                    .padding(.horizontal, hPad)


                    Button {
                        openInMaps()
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "paperplane")
                            Text("Åpne i Apple Maps").bold()
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .foregroundStyle(.white)
                        .background(Color.green, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, hPad)
                    .padding(.bottom, 10)
                }
                .padding(.top, 6)
            }
        }
        // Favoritt-ikon: øverst til høyre, uten bakgrunn
        .overlay(alignment: .topTrailing) {
            Button {
                toggleFavorite()
                Haptics.tap()
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(isFavorite ? Color("BeaconOrange") : .white)
                    .padding(12)
            }
            .buttonStyle(.plain)
            .padding(.trailing, 8)
            .padding(.top, 8)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0)) { animate = true }
            isFavorite = checkFavorite()
            avgRating = computeAverageRating()
            // Sett startverdi for input-stjerne basert på avrundet gjennomsnitt, eller 3 hvis ingen
            if let avg = avgRating {
                ratingValue = max(1, min(5, Int((avg).rounded())))
            } else {
                ratingValue = 3
            }
        }
    }

    // MARK: Rating funksjon
    private var ratingCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Gi din vurdering")
                .font(.headline)
                .foregroundStyle(primaryText)

            VStack(spacing: 10) {
                // Byttet til interaktiv ÉN stjerne: fylling styres av ratingValue/5.0
                InteractiveSingleStar(value: $ratingValue, size: 34)
                    .frame(height: 34)

                Text("\(ratingValue) / 5")
                    .font(.callout.weight(.semibold))
                    .foregroundStyle(primaryText)

                Text("Trykk eller dra over stjernen")
                    .font(.caption)
                    .foregroundStyle(secondaryText)

                Button {
                    saveRating(value: ratingValue)
                    Haptics.tap()
                } label: {
                    Text("Bekreft vurdering")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .foregroundStyle(.white)
                        .background(Color("BeaconOrange"),
                                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay(
                        Color("DeepBlue").opacity(0.82)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
            )
        }
    }

    // MARK: Åpne i kart knapp
    private func openInMaps() {
        let coordinate = place.coordinate
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        let item = MKMapItem(location: location, address: nil)
        item.name = place.name
        item.openInMaps(launchOptions: [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: coordinate)
        ])
    }

    // MARK: Favoritt håndtering
    private func toggleFavorite() {
        if let existing = fetchFavorite() {
            context.delete(existing)
        } else {
            context.insert(Favorite(
                placeId: place.id,
                name: place.name,
                address: place.address,
                lat: place.lat,
                lon: place.lon,
                categoryRaw: place.category.rawValue
            ))
        }
        try? context.save()
        isFavorite = checkFavorite()
    }

    private func fetchFavorite() -> Favorite? {
        let desc = FetchDescriptor<Favorite>(predicate: #Predicate { $0.placeId == place.id }, sortBy: [])
        return (try? context.fetch(desc))?.first
    }

    private func checkFavorite() -> Bool { fetchFavorite() != nil }

    
    // MARK: Rating håndtering
    private func saveRating(value: Int) {
        context.insert(Rating(placeId: place.id, value: value))
        try? context.save()
        avgRating = computeAverageRating()
        // NYTT: informer liste og pins med en gang
        NotificationCenter.default.post(name: Notification.Name("ratingDidChange"), object: place.id)
    }

    private func computeAverageRating() -> Double? {
        let desc = FetchDescriptor<Rating>(predicate: #Predicate { $0.placeId == place.id }, sortBy: [])
        if let all = try? context.fetch(desc), !all.isEmpty {
            let avg = Double(all.map { $0.value }.reduce(0, +)) / Double(all.count)
            return avg
        }
        return nil
    }
}


// MARK: Lokale komponenter for rating
private struct PercentFilledStarLocal: View {
    let fill: CGFloat // 0...1

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ZStack {
                Image(systemName: "star")
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(Color.white.opacity(0.35))
                Image(systemName: "star.fill")
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(Color("BeaconOrange"))
                    .mask(
                        Rectangle()
                            .frame(width: w * max(0, min(1, fill)), alignment: .leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    )
            }
        }
        .aspectRatio(1, contentMode: .fit)
    }
}

// Enkelt visning for gjennomsnittlig fyllingsgrad
private struct SingleFilledStarView: View {
    let fill: CGFloat // 0...1
    var body: some View {
        PercentFilledStarLocal(fill: fill)
    }
}

// Interaktiv én-stjerne-rating: sett 1...5 basert på drag/tap over stjernens bredde
private struct InteractiveSingleStar: View {
    @Binding var value: Int // 1...5
    var size: CGFloat = 34

    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            PercentFilledStarLocal(fill: CGFloat(value) / 5.0)
                .frame(maxWidth: .infinity, alignment: .center)
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { g in
                            let x = max(0, min(g.location.x, width))
                            let segment = width / 5.0
                            let index = Int((x / segment).rounded(.up))
                            value = max(1, min(5, index))
                        }
                        .onEnded { _ in Haptics.tap() }
                )
                .onTapGesture { location in
                    let x = max(0, min(location.x, width))
                    let segment = width / 5.0
                    let index = Int((x / segment).rounded(.up))
                    value = max(1, min(5, index))
                    Haptics.tap()
                }
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Vurdering")
        .accessibilityValue("\(value) av 5")
    }
}
