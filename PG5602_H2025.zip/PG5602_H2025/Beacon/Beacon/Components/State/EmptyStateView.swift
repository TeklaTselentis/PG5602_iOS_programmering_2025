// Håndterer senarioer med å vise enkel tomtilstand med ikon og tekst.
import SwiftUI

// MARK: Årsak til tomtilstand
enum EmptyReason {
    case notFetchedYet
    case noResultsNearby
    case filteredOut
    case apiError(String)
}

// MARK: Tomtilstand view
struct EmptyStateView: View {
    let reason: EmptyReason

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: iconName)
                .font(.system(size: 48))
                .foregroundStyle(.white)

            Text(title)
                .font(.headline)
                .foregroundStyle(.white)

            if let message = message {
                Text(message)
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 12)
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
    }

    // MARK: Tekst og ikonbasert på årsak
    private var iconName: String {
        switch reason {
        case .notFetchedYet:   return "arrow.down.circle"
        case .noResultsNearby: return "mappin.slash.circle"
        case .filteredOut:     return "line.3.horizontal.decrease.circle"
        case .apiError:        return "exclamationmark.triangle"
        }
    }

    // MARK: Titteltekst som viser forklaring på tomtilstand
    private var title: String {
        switch reason {
        case .notFetchedYet:   return "Ingen treff ennå"
        case .noResultsNearby: return "Ingen steder funnet"
        case .filteredOut:     return "Ingen treff med valgte filter"
        case .apiError:        return "Kunne ikke hente steder"
        }
    }

    // Mer detaljert forklaringstekst
    private var message: String? {
        switch reason {
        case .notFetchedYet:
            return "Trykk på Hent for å finne steder i nærheten."
        case .noResultsNearby:
            return "Vi fant ingen steder innen valgt radius. Prøv å øke radius eller flytt kartet."
        case .filteredOut:
            return "Ingen resultater som matcher filtrene dine. Juster søkeord eller nullstill filter."
        case .apiError(let msg):
            return msg
        }
    }
}
