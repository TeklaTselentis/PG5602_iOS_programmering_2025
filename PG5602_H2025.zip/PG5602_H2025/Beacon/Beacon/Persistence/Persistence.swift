// Setter opp SwiftData containeren med modellene som brukes i appen.

import Foundation
import SwiftData

enum Persistence {
    static func container() throws -> ModelContainer {
        let schema = Schema([Rating.self, Favorite.self])
        return try ModelContainer(for: schema)
    }
}
