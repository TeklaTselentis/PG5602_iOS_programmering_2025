// Hjelper for å lage en region rundt et punkt med standard zoom.

import MapKit

extension MKCoordinateRegion {
    static func around(_ coord: CLLocationCoordinate2D, span: CLLocationDegrees = 0.05) -> MKCoordinateRegion {
        .init(center: coord, span: .init(latitudeDelta: span, longitudeDelta: span))
    }
}
