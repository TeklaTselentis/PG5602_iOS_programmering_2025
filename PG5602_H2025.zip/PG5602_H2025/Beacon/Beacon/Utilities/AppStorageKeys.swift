// Samler nøkkel strenger som brukes med @AppStorage

enum AppStorageKeys {
    static let centerLatitude   = "centerLatitude"
    static let centerLongitude  = "centerLongitude"
    static let searchRadiusKm   = "searchRadiusKm"
    static let lastCategory     = "lastCategory"
}
