// Samler enkel haptiks feedback som brukes overalt i appen.

import UIKit

enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
}
