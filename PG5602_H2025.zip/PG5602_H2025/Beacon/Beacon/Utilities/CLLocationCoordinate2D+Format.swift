// Gir en kort tekstrepresentasjon av koordinater i UI.

import CoreLocation

extension CLLocationCoordinate2D {
    var shortString: String {
        String(format: "%.4f,  %.4f", latitude, longitude)
    }
}
