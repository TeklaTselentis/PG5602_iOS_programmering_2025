// Enkel debouncer som utsetter en handling med noen millisekunder

import Foundation

actor Debouncer {
    private var task: Task<Void, Never>?

    func schedule(ms: Int, _ action: @escaping () -> Void) {
        task?.cancel()
        task = Task { [ms] in
            try? await Task.sleep(nanoseconds: UInt64(ms) * 1_000_000)
            if Task.isCancelled { return }
            action()
        }
    }
}
