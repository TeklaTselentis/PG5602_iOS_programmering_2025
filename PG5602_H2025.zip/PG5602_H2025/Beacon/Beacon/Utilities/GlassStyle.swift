// Felles knappestil

import SwiftUI

struct SmallRoundButtonStyle: ButtonStyle {
    var backgroundStyle: AnyShapeStyle = AnyShapeStyle(.ultraThinMaterial)

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 40, height: 40)
            .background(backgroundStyle, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
            .scaleEffect(configuration.isPressed ? 0.96 : 1.0)
    }
}
