// Samling av faste konstanter som standard koordinater,radius og debounce osv som brukes i appen.

import Foundation
import CoreLocation


// MARK: Globale app konstanter
enum AppConstants {
    
    // Default lokasjon til førstegangsoppstart.
    static let defaultCenter = CLLocationCoordinate2D(latitude: 59.9111, longitude: 10.7503)
    
    // Minimum radius som kan brukes ved søk rundt et punkt.
    static let minRadiusKm: Double = 1
    
    // Minimum radius som kan brukes ved søk rundt et punkt.
    static let maxRadiusKm: Double = 10
    
    // Standard debounce tid for søk og API-kall
    static let debounceMs: Int = 300
    
}
