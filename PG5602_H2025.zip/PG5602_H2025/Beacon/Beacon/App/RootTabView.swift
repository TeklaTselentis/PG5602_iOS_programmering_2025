// Håndterer hovednavigasjonen i appen.
// Gir brukeren mulighet til å bytte mellom fanene "Utforsk" (kart + liste) og "Mine steder" (favoritter).

import SwiftUI

struct RootTabView: View {
    
    // MARK: ViewModels
    
    @StateObject private var exploreVM = ExploreViewModel()
    @StateObject private var filtersVM = FiltersViewModel()

    
    // MARK: UI state
    
    // Hvilke fane som er valgt, 0 = Utforsk og 1 = Mine steder
    @State private var selection: Int = 0
    
    
    // MARK: UI
    var body: some View {
        TabView(selection: $selection) {
            
            // Fane 1: Utforsk (kart + liste)
            ExploreView(exploreVM: exploreVM, filtersVM: filtersVM)
                .tag(0)
                .tabItem { Label("Utforsk", systemImage: "map") }
            
            // Fane 2: Mine steder (favoritter)
            FavoritesView()
                .tag(1)
                .tabItem { Label("Mine steder", systemImage: "heart") }
        }
        .tint(Color("BeaconOrange"))
    }
}
