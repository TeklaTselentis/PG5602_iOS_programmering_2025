// Oppstarts punkt for appen.
// Setter opp SwiftData container og viser rot visningen.

import SwiftUI
import SwiftData

@main
struct BeaconApp: App {
    
// MARK: SwiftData konfigurasjon
    
    // Container for alle modellene i appen.
    private let container: ModelContainer = {
        do {
            // Forsøk på å lagre data på disk.
            return try Persistence.container()
        } catch {
            // Logging av feilen og lager en midlertidig løsning.
            print("Feil ved lasting av SwiftData-container \(error) — bruker kun minne isteden.")
            // Midlertidig løsning.
            do {
                let schema = Schema([Rating.self, Favorite.self])
                let config = ModelConfiguration(isStoredInMemoryOnly: true)
                return try ModelContainer(for: schema, configurations: config)
            } catch {
                // Feilmelding hvis de to alternativene ikke funker.
                fatalError("Failed to create even an in-memory SwiftData container: \(error)")
            }
        }
    }()

// MARK: Scene
    var body: some Scene {
        WindowGroup {
            // Rot visningen til appen, "Utforsk" og "Mine steder"
            RootTabView()
        }
        // Gjør SwiftData container tilgjengelig i alle underliggende views.
        .modelContainer(container)
    }
}
